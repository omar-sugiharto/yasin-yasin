@extends('templates.admin')

@section('title')
	Dasbor
@endsection

@section('breadcrumb')
	Dasbor
@endsection